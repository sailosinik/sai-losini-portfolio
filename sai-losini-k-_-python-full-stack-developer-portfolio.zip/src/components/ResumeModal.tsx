import React from 'react';
import { X, Download, ExternalLink, FileText, CheckCircle2 } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-4xl bg-[#0D1224] border border-[#A78BFA]/30 rounded-2xl shadow-2xl flex flex-col h-[90vh] overflow-hidden text-left relative">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#090D1A] border-b border-white/[0.08] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#A78BFA]/20 text-[#A78BFA]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#F3F4FF]">
                {PERSONAL_INFO.name} — Resume Document
              </h3>
              <p className="text-xs text-[#A0A7C0]">
                Python Full Stack Developer · B.E. (CGPA 8.16)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href={PERSONAL_INFO.resumePath}
              download="Sai_Losini_K_Resume.pdf"
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#A78BFA] to-[#60A5FA] text-[#080B16] text-xs font-semibold hover:opacity-95 transition-opacity"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </a>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-[#161D36] text-[#A0A7C0] hover:text-white transition-colors"
              aria-label="Close resume preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PDF Embedded Frame */}
        <div className="flex-1 bg-[#12172B] relative overflow-hidden">
          <iframe
            src={`${PERSONAL_INFO.resumePath}#toolbar=1&navpanes=0`}
            title="Sai Losini K Resume PDF"
            className="w-full h-full border-none"
          />
        </div>

        {/* Modal Footer info */}
        <div className="px-6 py-3 bg-[#090D1A] border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between text-xs text-[#A0A7C0] gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#4ADE80]" />
            <span>Directly sourced from uploaded resume PDF in repository</span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href={PERSONAL_INFO.resumePath}
              target="_blank"
              rel="noreferrer"
              className="hover:text-[#F3F4FF] transition-colors flex items-center gap-1"
            >
              <span>Open in new tab</span>
              <ExternalLink className="w-3 h-3 text-[#A78BFA]" />
            </a>
          </div>
        </div>

      </div>
    </div>
  );
};
