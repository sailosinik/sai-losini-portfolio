import React from 'react';
import { X, BookOpen, FileText, Code2, Terminal, CheckCircle2, Link2, ExternalLink } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface SetupGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SetupGuideModal: React.FC<SetupGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-2xl bg-[#0D1224] border border-[#A78BFA]/30 rounded-2xl shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto text-left relative">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-[#161D36] text-[#A0A7C0] hover:text-white hover:bg-[#1E2646] transition-colors"
          aria-label="Close setup guide"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-xs font-code text-[#A78BFA] mb-2">
          <BookOpen className="w-4 h-4" />
          <span>Developer Guide & Maintenance</span>
        </div>

        <h3 className="text-2xl font-bold text-[#F3F4FF]">
          How to Run, Update & Customize
        </h3>

        <p className="text-sm text-[#A0A7C0] mt-1">
          Complete instructions for updating your resume, project links, social handles, and running the website.
        </p>

        <div className="mt-6 space-y-6 text-sm">
          
          {/* Step 1: Running the project */}
          <div className="p-4 rounded-xl bg-[#090D1C] border border-white/[0.06] space-y-2">
            <div className="flex items-center gap-2 font-bold text-[#F3F4FF]">
              <Terminal className="w-4 h-4 text-[#A78BFA]" />
              <span>1. How to Run the Project Locally</span>
            </div>
            <p className="text-xs text-[#A0A7C0]">
              The project is a standard Vite + React SPA. In your terminal, run:
            </p>
            <pre className="p-2.5 rounded-lg bg-[#050811] text-xs font-code text-[#4ADE80] overflow-x-auto">
              <code>npm install{'\n'}npm run dev</code>
            </pre>
            <p className="text-xs text-[#A0A7C0]">
              Open your browser at <span className="font-code text-[#60A5FA]">http://localhost:3000</span> to view your portfolio.
            </p>
          </div>

          {/* Step 2: Updating the Resume PDF */}
          <div className="p-4 rounded-xl bg-[#090D1C] border border-white/[0.06] space-y-2">
            <div className="flex items-center gap-2 font-bold text-[#F3F4FF]">
              <FileText className="w-4 h-4 text-[#60A5FA]" />
              <span>2. How to Add or Update Your Resume PDF</span>
            </div>
            <p className="text-xs text-[#A0A7C0] leading-relaxed">
              Your uploaded resume has been placed in the public directory:
            </p>
            <ul className="text-xs text-[#A0A7C0] space-y-1 list-disc list-inside">
              <li><span className="font-code text-[#F3F4FF]">/public/Sai_Losini_K_Resume.pdf</span> (Clean direct download)</li>
              <li><span className="font-code text-[#F3F4FF]">/public/assets/aistudio/sailosinik_resume_._3ffcaf76.pdf</span> (Original source)</li>
            </ul>
            <p className="text-xs text-[#A0A7C0]">
              Whenever you update your resume, simply export your new PDF and replace <span className="font-code text-[#A78BFA]">public/Sai_Losini_K_Resume.pdf</span>. Both the Download and Preview buttons will automatically serve your latest version!
            </p>
          </div>

          {/* Step 3: Updating GitHub, LinkedIn & Project Links */}
          <div className="p-4 rounded-xl bg-[#090D1C] border border-white/[0.06] space-y-2">
            <div className="flex items-center gap-2 font-bold text-[#F3F4FF]">
              <Link2 className="w-4 h-4 text-[#4ADE80]" />
              <span>3. Updating Links & Profile Information</span>
            </div>
            <p className="text-xs text-[#A0A7C0] leading-relaxed">
              All personal details, skills, project links, and experiences are centralized cleanly in:
            </p>
            <pre className="p-2.5 rounded-lg bg-[#050811] text-xs font-code text-[#A78BFA] overflow-x-auto">
              <code>src/data/portfolioData.ts</code>
            </pre>
            <p className="text-xs text-[#A0A7C0] leading-relaxed">
              Open that file to update:
            </p>
            <ul className="text-xs text-[#A0A7C0] space-y-1 list-disc list-inside">
              <li><strong className="text-[#F3F4FF]">PERSONAL_INFO.github</strong> / <strong className="text-[#F3F4FF]">linkedin</strong> / <strong className="text-[#F3F4FF]">email</strong> / <strong className="text-[#F3F4FF]">phone</strong></li>
              <li><strong className="text-[#F3F4FF]">PROJECTS</strong>: Change GitHub repository links or add live demo URLs to each project.</li>
              <li><strong className="text-[#F3F4FF]">EXPERIENCES</strong> / <strong className="text-[#F3F4FF]">EDUCATION</strong>: Add future roles and degrees as you advance your career.</li>
            </ul>
          </div>

          {/* Step 4: Professional Custom Domain Setup */}
          <div className="p-4 rounded-xl bg-[#090D1C] border border-[#A78BFA]/20 space-y-3">
            <div className="flex items-center gap-2 font-bold text-[#F3F4FF]">
              <ExternalLink className="w-4 h-4 text-[#A78BFA]" />
              <span>4. How to Get a Professional Domain (No "ai.studio" in link)</span>
            </div>
            <p className="text-xs text-[#A0A7C0] leading-relaxed">
              The <span className="font-code text-[#A78BFA]">.ai.studio</span> or <span className="font-code text-[#60A5FA]">.run.app</span> URL is only the internal preview environment. To have a clean URL to share with recruiters:
            </p>
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg bg-[#050811] border border-white/[0.04]">
                <strong className="text-[#4ADE80] block mb-0.5">Option A: 100% Free Developer Domain (GitHub Pages / Vercel)</strong>
                <p className="text-[#A0A7C0]">Push your code to your GitHub repo (<span className="font-code text-[#F3F4FF]">github.com/sailosinik/portfolio</span>) and deploy for free to get: <br /><span className="font-code text-[#60A5FA]">https://sailosinik.github.io</span> or <span className="font-code text-[#60A5FA]">https://sailosini.vercel.app</span></p>
              </div>
              <div className="p-2.5 rounded-lg bg-[#050811] border border-white/[0.04]">
                <strong className="text-[#A78BFA] block mb-0.5">Option B: Custom Domain (Recommended for Recruiters)</strong>
                <p className="text-[#A0A7C0]">Purchase your own personal domain (e.g., <span className="font-code text-[#F3F4FF]">sailosini.dev</span> or <span className="font-code text-[#F3F4FF]">sailosinik.com</span>) for ~$8–$12/year from Namecheap, Cloudflare, or GoDaddy, and connect it to Vercel/GitHub Pages with 1 click. Zero platform branding!</p>
              </div>
            </div>
          </div>

        </div>

        <div className="mt-6 pt-4 border-t border-white/[0.08] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#A78BFA] text-[#080B16] font-semibold text-xs hover:bg-[#A78BFA]/90 transition-colors"
          >
            Got It
          </button>
        </div>

      </div>
    </div>
  );
};
