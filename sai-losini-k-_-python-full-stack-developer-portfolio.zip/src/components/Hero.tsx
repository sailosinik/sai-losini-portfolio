import React, { useState } from 'react';
import { Download, ArrowRight, Mail, Play, CheckCircle2, Copy, Check, Terminal, Sparkles, Layers } from 'lucide-react';
import { PERSONAL_INFO, CODE_SNIPPETS } from '../data/portfolioData';

interface HeroProps {
  onOpenResumeModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResumeModal }) => {
  const [activeTab, setActiveTab] = useState<'etl' | 'flask' | 'sql'>('etl');
  const [isRunning, setIsRunning] = useState(false);
  const [runOutput, setRunOutput] = useState<string | null>(null);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  const activeCodeObj = CODE_SNIPPETS[activeTab];

  const handleRunSimulation = () => {
    setIsRunning(true);
    setRunOutput(null);

    setTimeout(() => {
      setIsRunning(false);
      if (activeTab === 'etl') {
        setRunOutput("✓ [ETL Executed] 1,420 rows extracted · Computed margins (avg 24.8%) · Loaded into PostgreSQL warehouse table 'sales_analytics'.");
      } else if (activeTab === 'flask') {
        setRunOutput("✓ [Flask Server Ready] Running on http://127.0.0.1:5000/ · SQLAlchemy mapped models: 'Application' · Endpoint /api/applications 200 OK");
      } else {
        setRunOutput("✓ [PostgreSQL DDL Ready] Created table sales_analytics · Indexes created on customer_region & product_category · Aggregations verified.");
      }
    }, 600);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeCodeObj.code);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  const handleScroll = (id: string) => {
    const el = document.querySelector(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
      {/* Subtle radial ambient gradients (Dark palette #080B16 with purple #A78BFA & blue #60A5FA accents) */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-tr from-[#A78BFA]/15 via-[#60A5FA]/10 to-transparent blur-[120px] pointer-events-none -z-10" />
      <div className="absolute top-10 right-10 w-96 h-96 bg-[#60A5FA]/10 blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Typographic Hierarchy */}
          <div className="lg:col-span-6 space-y-6 text-left">
            {/* Status kicker */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#161D36]/80 border border-white/[0.08] text-xs text-[#A0A7C0]">
              <span className="w-2 h-2 rounded-full bg-[#4ADE80]" />
              <span className="font-medium text-[#F3F4FF]">{PERSONAL_INFO.status}</span>
            </div>

            {/* Name & Title */}
            <div>
              <p className="text-sm font-semibold tracking-wider text-[#A78BFA] uppercase mb-2">
                Hello, I am
              </p>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#F3F4FF] tracking-tight leading-[1.1]">
                {PERSONAL_INFO.name}
              </h1>
              <div className="mt-2 text-xl sm:text-2xl font-semibold bg-gradient-to-r from-[#A78BFA] via-[#60A5FA] to-[#4ADE80] bg-clip-text text-transparent">
                {PERSONAL_INFO.title}
              </div>
            </div>

            {/* Executive Introduction based on actual resume */}
            <p className="text-base sm:text-lg text-[#A0A7C0] leading-relaxed max-w-xl">
              {PERSONAL_INFO.bio}
            </p>

            {/* Career Goal callout */}
            <div className="p-4 rounded-xl bg-[#0F1426]/60 border border-white/[0.08] max-w-xl">
              <div className="text-xs uppercase tracking-wider text-[#A78BFA] font-semibold mb-1">
                Career Goal
              </div>
              <p className="text-sm text-[#F3F4FF]/90 italic">
                "{PERSONAL_INFO.careerGoal}"
              </p>
            </div>

            {/* Action Buttons: View Projects, Download Resume, Contact Me */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => handleScroll('#projects')}
                className="flex items-center gap-2 px-5 py-3 text-sm font-semibold text-[#080B16] bg-gradient-to-r from-[#A78BFA] to-[#60A5FA] hover:opacity-95 rounded-xl transition-all duration-200 shadow-lg shadow-[#A78BFA]/25 cursor-pointer whitespace-nowrap"
              >
                <span>View My Projects</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={PERSONAL_INFO.resumePath}
                download="Sai_Losini_K_Resume.pdf"
                className="flex items-center gap-2 px-5 py-3 text-sm font-semibold text-[#F3F4FF] bg-[#161D36] border border-white/[0.12] hover:border-[#A78BFA]/50 hover:bg-[#1E2749] rounded-xl transition-all duration-200 cursor-pointer whitespace-nowrap"
              >
                <Download className="w-4 h-4 text-[#A78BFA]" />
                <span>Download Resume</span>
              </a>

              <button
                onClick={() => handleScroll('#contact')}
                className="flex items-center gap-2 px-4 py-3 text-sm font-medium text-[#A0A7C0] hover:text-[#F3F4FF] transition-colors cursor-pointer whitespace-nowrap"
              >
                <Mail className="w-4 h-4 text-[#60A5FA]" />
                <span>Contact Me</span>
              </button>
            </div>

            {/* Contact quick tags */}
            <div className="pt-2 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-[#A0A7C0]">
              <span className="flex items-center gap-1.5">
                <span className="text-[#A78BFA]">📍</span> Chennai, India
              </span>
              <span>·</span>
              <a
                href={PERSONAL_INFO.github}
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#F3F4FF] transition-colors"
              >
                github.com/sailosinik
              </a>
              <span>·</span>
              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noreferrer"
                className="hover:text-[#F3F4FF] transition-colors"
              >
                linkedin.com/in/sai-losini
              </a>
            </div>
          </div>

          {/* Right Column: Interactive Developer-Themed IDE Visual */}
          <div className="lg:col-span-6 w-full">
            <div className="relative rounded-2xl bg-[#0D1224]/90 border border-white/[0.1] shadow-2xl shadow-black/80 overflow-hidden backdrop-blur-xl">
              
              {/* Window Titlebar */}
              <div className="px-4 py-3 bg-[#090D1A] border-b border-white/[0.08] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#EF4444]/80" />
                  <div className="w-3 h-3 rounded-full bg-[#F59E0B]/80" />
                  <div className="w-3 h-3 rounded-full bg-[#10B981]/80" />
                  <span className="ml-3 text-xs font-code text-[#A0A7C0] hidden sm:inline">
                    sai_losini_workspace — python-fullstack
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyCode}
                    className="p-1.5 rounded text-[#A0A7C0] hover:text-[#F3F4FF] hover:bg-white/[0.05] transition-colors text-xs flex items-center gap-1 font-code"
                    title="Copy Code"
                  >
                    {copiedSnippet ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
                        <span className="text-[#4ADE80]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Copy</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleRunSimulation}
                    disabled={isRunning}
                    className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#A78BFA]/20 border border-[#A78BFA]/30 hover:bg-[#A78BFA]/30 text-xs font-semibold text-[#A78BFA] transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>{isRunning ? "Running..." : "Run"}</span>
                  </button>
                </div>
              </div>

              {/* Code File Tabs */}
              <div className="flex items-center bg-[#070A14] border-b border-white/[0.06] overflow-x-auto text-xs font-code">
                <button
                  onClick={() => { setActiveTab('etl'); setRunOutput(null); }}
                  className={`px-4 py-2.5 border-r border-white/[0.06] flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'etl'
                      ? 'bg-[#0D1224] text-[#A78BFA] border-t-2 border-t-[#A78BFA]'
                      : 'text-[#A0A7C0] hover:text-[#F3F4FF] hover:bg-white/[0.02]'
                  }`}
                >
                  <span className="text-yellow-400">🐍</span>
                  <span>sales_pipeline.py</span>
                </button>

                <button
                  onClick={() => { setActiveTab('flask'); setRunOutput(null); }}
                  className={`px-4 py-2.5 border-r border-white/[0.06] flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'flask'
                      ? 'bg-[#0D1224] text-[#A78BFA] border-t-2 border-t-[#A78BFA]'
                      : 'text-[#A0A7C0] hover:text-[#F3F4FF] hover:bg-white/[0.02]'
                  }`}
                >
                  <span className="text-blue-400">⚡</span>
                  <span>app.py (Flask)</span>
                </button>

                <button
                  onClick={() => { setActiveTab('sql'); setRunOutput(null); }}
                  className={`px-4 py-2.5 border-r border-white/[0.06] flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === 'sql'
                      ? 'bg-[#0D1224] text-[#A78BFA] border-t-2 border-t-[#A78BFA]'
                      : 'text-[#A0A7C0] hover:text-[#F3F4FF] hover:bg-white/[0.02]'
                  }`}
                >
                  <span className="text-cyan-400">🗄️</span>
                  <span>schema.sql</span>
                </button>
              </div>

              {/* Code Editor Pane */}
              <div className="p-4 sm:p-5 text-left overflow-x-auto max-h-[340px] font-code text-xs sm:text-[13px] leading-relaxed text-[#F3F4FF] select-text">
                <pre className="text-[#A0A7C0]">
                  <code>
                    {activeCodeObj.code.split('\n').map((line, idx) => (
                      <div key={idx} className="table-row">
                        <span className="table-cell pr-4 text-right select-none text-white/20 text-xs">
                          {idx + 1}
                        </span>
                        <span className="table-cell whitespace-pre text-[#E2E8F0]">
                          {highlightSyntax(line)}
                        </span>
                      </div>
                    ))}
                  </code>
                </pre>
              </div>

              {/* Execution Console Output */}
              {runOutput && (
                <div className="p-3.5 bg-[#050811] border-t border-[#4ADE80]/30 text-xs font-code text-[#4ADE80] flex items-start gap-2 animate-fadeIn text-left">
                  <Terminal className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{runOutput}</span>
                </div>
              )}

              {/* Editor Footer / Info bar */}
              <div className="px-4 py-2 bg-[#090D1A] border-t border-white/[0.06] flex items-center justify-between text-[11px] text-[#A0A7C0] font-code">
                <div className="flex items-center gap-3">
                  <span>UTF-8</span>
                  <span>·</span>
                  <span>Python 3.11</span>
                  <span>·</span>
                  <span className="text-[#A78BFA]">PostgreSQL Connected</span>
                </div>
                <div className="hidden sm:flex items-center gap-1.5 text-[#4ADE80]">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Syntax Validated</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Column Proof Row below Hero Split */}
        <div className="mt-16 pt-8 border-t border-white/[0.08] grid grid-cols-2 md:grid-cols-4 gap-6 text-left">
          <div className="p-4 rounded-xl bg-[#0F1426]/40 border border-white/[0.05]">
            <div className="text-2xl font-bold font-code text-[#A78BFA] tabular-nums">
              8.16 / 10
            </div>
            <div className="text-xs text-[#A0A7C0] mt-1 font-medium">
              B.E. CGPA (Instrumentation & Control)
            </div>
            <div className="text-[11px] text-[#A0A7C0]/70 mt-0.5">
              Sri Sairam Engineering College
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0F1426]/40 border border-white/[0.05]">
            <div className="text-2xl font-bold font-code text-[#60A5FA]">
              Published Patent
            </div>
            <div className="text-xs text-[#A0A7C0] mt-1 font-medium">
              Indian Patent Platform Filed
            </div>
            <div className="text-[11px] text-[#A0A7C0]/70 mt-0.5">
              Smart Plastic Recycling Machine
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0F1426]/40 border border-white/[0.05]">
            <div className="text-2xl font-bold font-code text-[#4ADE80]">
              2x Awards
            </div>
            <div className="text-xs text-[#A0A7C0] mt-1 font-medium">
              Hack Summit 5.0 & Hacklite 1st Prize
            </div>
            <div className="text-[11px] text-[#A0A7C0]/70 mt-0.5">
              ₹10,000 Cash Prize Winner
            </div>
          </div>

          <div className="p-4 rounded-xl bg-[#0F1426]/40 border border-white/[0.05]">
            <div className="text-2xl font-bold font-code text-[#F3F4FF]">
              2 Internships
            </div>
            <div className="text-xs text-[#A0A7C0] mt-1 font-medium">
              Automotive Electronics (2025)
            </div>
            <div className="text-[11px] text-[#A0A7C0]/70 mt-0.5">
              GT Electronic & KIML
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

// Simple syntax highlighter helper for code snippet aesthetic
function highlightSyntax(line: string) {
  if (line.trim().startsWith('#') || line.trim().startsWith('--') || line.trim().startsWith('"""')) {
    return <span className="text-slate-500 italic">{line}</span>;
  }
  if (line.includes('def ') || line.includes('class ') || line.includes('import ') || line.includes('from ')) {
    return <span className="text-[#A78BFA]">{line}</span>;
  }
  if (line.includes('return ') || line.includes('SELECT ') || line.includes('INSERT INTO ') || line.includes('CREATE TABLE ')) {
    return <span className="text-[#60A5FA] font-medium">{line}</span>;
  }
  return <span>{line}</span>;
}
