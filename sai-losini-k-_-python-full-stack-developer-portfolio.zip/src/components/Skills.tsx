import React, { useState } from 'react';
import { SKILL_CATEGORIES } from '../data/portfolioData';
import { Code, Database, Cloud, Wrench, Users, CheckCircle, Sparkles } from 'lucide-react';

export const Skills: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categoryIcons: Record<string, React.ReactNode> = {
    'Languages & Concepts': <Code className="w-4 h-4 text-[#A78BFA]" />,
    'Web & Backend': <Code className="w-4 h-4 text-[#60A5FA]" />,
    'Databases': <Database className="w-4 h-4 text-[#4ADE80]" />,
    'Cloud, BI & Tools': <Cloud className="w-4 h-4 text-[#A78BFA]" />,
    'Soft Skills': <Users className="w-4 h-4 text-[#60A5FA]" />,
  };

  const categories = ['All', ...SKILL_CATEGORIES.map((c) => c.category)];

  const displayedCategories =
    selectedCategory === 'All'
      ? SKILL_CATEGORIES
      : SKILL_CATEGORIES.filter((c) => c.category === selectedCategory);

  return (
    <section id="skills" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 text-left">
          <div>
            <p className="text-xs uppercase tracking-widest font-semibold text-[#A78BFA] mb-2 font-code">
              02. Technical Competencies
            </p>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#F3F4FF] tracking-tight">
              Skills & Expertise
            </h2>
            <p className="text-[#A0A7C0] text-sm sm:text-base mt-2 max-w-xl">
              Authentic technical capabilities directly applied in full-stack projects, data engineering pipelines, and cloud environments.
            </p>
          </div>

          {/* Interactive Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-[#0F1426]/80 border border-white/[0.08] self-start md:self-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all duration-200 whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-gradient-to-r from-[#A78BFA]/30 to-[#60A5FA]/30 text-[#F3F4FF] border border-[#A78BFA]/40 shadow-sm'
                    : 'text-[#A0A7C0] hover:text-[#F3F4FF] hover:bg-white/[0.04]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Skill Groups Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {displayedCategories.map((group) => (
            <div
              key={group.category}
              className="p-6 rounded-2xl bg-[#0F1426]/70 border border-white/[0.08] hover:border-[#A78BFA]/30 transition-all duration-300 backdrop-blur-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-2.5 pb-4 mb-4 border-b border-white/[0.06]">
                  <div className="p-2 rounded-lg bg-[#161D36] border border-white/[0.08]">
                    {categoryIcons[group.category] || <Sparkles className="w-4 h-4 text-[#A78BFA]" />}
                  </div>
                  <h3 className="text-base font-semibold text-[#F3F4FF]">
                    {group.category}
                  </h3>
                </div>

                <div className="space-y-3">
                  {group.skills.map((skill) => (
                    <div
                      key={skill.name}
                      className="p-3 rounded-xl bg-[#090D1C]/60 border border-white/[0.04] hover:border-white/[0.1] transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-semibold text-[#F3F4FF]">
                          {skill.name}
                        </span>
                        <span className="text-[11px] text-[#A78BFA] font-code">
                          Verified
                        </span>
                      </div>
                      <p className="text-xs text-[#A0A7C0] mt-1 leading-relaxed">
                        {skill.highlight}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-white/[0.04] flex items-center justify-between text-[11px] text-[#A0A7C0]">
                <span>{group.skills.length} competencies</span>
                <span className="text-[#60A5FA]">Resume Verified</span>
              </div>
            </div>
          ))}
        </div>

        {/* AWS & Cloud Specific Breakdown Banner */}
        <div className="mt-8 p-6 rounded-2xl bg-gradient-to-r from-[#0F1426]/90 via-[#141A33]/80 to-[#0F1426]/90 border border-[#A78BFA]/20 text-left">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-4">
              <span className="text-xs font-code uppercase text-[#A78BFA] font-semibold tracking-wider">
                Cloud Architecture
              </span>
              <h4 className="text-lg font-bold text-[#F3F4FF] mt-1">
                AWS Ecosystem Knowledge
              </h4>
              <p className="text-xs text-[#A0A7C0] mt-1">
                Hands-on practical understanding of core Amazon Web Services for scalable deployments.
              </p>
            </div>
            
            <div className="md:col-span-8 flex flex-wrap gap-2.5">
              {[
                { name: 'Amazon S3', desc: 'Object Storage & Static Assets' },
                { name: 'Amazon EC2', desc: 'Compute & Linux Virtual Servers' },
                { name: 'AWS Lambda', desc: 'Serverless Functions' },
                { name: 'AWS IAM', desc: 'Role Policies & Secure Access' },
                { name: 'DynamoDB', desc: 'NoSQL Document Store' },
              ].map((awsService) => (
                <div
                  key={awsService.name}
                  className="px-3.5 py-2 rounded-xl bg-[#090D1C] border border-white/[0.08] hover:border-[#60A5FA]/40 transition-colors"
                >
                  <div className="text-xs font-semibold text-[#F3F4FF]">{awsService.name}</div>
                  <div className="text-[10px] text-[#A0A7C0]">{awsService.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
