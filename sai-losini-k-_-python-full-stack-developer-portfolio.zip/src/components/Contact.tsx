import React, { useState } from 'react';
import { Mail, Phone, MapPin, Linkedin, Github, Send, Copy, Check, CheckCircle2, AlertCircle } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2500);
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Please provide your full name.';
    if (!formData.email.trim()) {
      errs.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = 'Please provide a valid email format (e.g., name@example.com).';
    }
    if (!formData.subject.trim()) errs.subject = 'Please provide a subject line.';
    if (!formData.message.trim()) {
      errs.message = 'Please provide your message.';
    } else if (formData.message.trim().length < 15) {
      errs.message = 'Message must be at least 15 characters.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      setIsSubmitted(true);
    }
  };

  const mailtoUrl = `mailto:${PERSONAL_INFO.email}?subject=${encodeURIComponent(
    formData.subject || 'Portfolio Inquiry for Sai Losini K'
  )}&body=${encodeURIComponent(
    `From: ${formData.name} (${formData.email})\n\nMessage:\n${formData.message}`
  )}`;

  return (
    <section id="contact" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-14 text-left">
          <p className="text-xs uppercase tracking-widest font-semibold text-[#A78BFA] mb-2 font-code">
            07. Let's Connect
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#F3F4FF] tracking-tight">
            Contact & Hire
          </h2>
          <p className="text-[#A0A7C0] text-sm sm:text-base mt-2 max-w-xl">
            Currently available for entry-level Software Developer and Python Full Stack roles in Chennai or remote.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Contact Details Cards - 5 Columns */}
          <div className="lg:col-span-5 space-y-4 text-left">
            
            {/* Email Card */}
            <div className="p-5 rounded-2xl bg-[#0F1426]/75 border border-white/[0.08] backdrop-blur-md flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="p-2.5 rounded-xl bg-[#A78BFA]/10 text-[#A78BFA]">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-[#A0A7C0] font-code">Email Address</div>
                  <a
                    href={`mailto:${PERSONAL_INFO.email}`}
                    className="text-sm font-semibold text-[#F3F4FF] hover:text-[#A78BFA] transition-colors"
                  >
                    {PERSONAL_INFO.email}
                  </a>
                </div>
              </div>

              <button
                onClick={() => handleCopy(PERSONAL_INFO.email, 'email')}
                className="p-2 rounded-lg bg-[#161D36] text-[#A0A7C0] hover:text-[#F3F4FF] transition-colors text-xs flex items-center gap-1 font-code"
                title="Copy Email"
              >
                {copiedField === 'email' ? (
                  <Check className="w-4 h-4 text-[#4ADE80]" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Phone Card */}
            <div className="p-5 rounded-2xl bg-[#0F1426]/75 border border-white/[0.08] backdrop-blur-md flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="p-2.5 rounded-xl bg-[#60A5FA]/10 text-[#60A5FA]">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-[#A0A7C0] font-code">Phone / WhatsApp</div>
                  <a
                    href={`tel:${PERSONAL_INFO.phone}`}
                    className="text-sm font-semibold text-[#F3F4FF] hover:text-[#60A5FA] transition-colors"
                  >
                    {PERSONAL_INFO.phone}
                  </a>
                </div>
              </div>

              <button
                onClick={() => handleCopy(PERSONAL_INFO.phone, 'phone')}
                className="p-2 rounded-lg bg-[#161D36] text-[#A0A7C0] hover:text-[#F3F4FF] transition-colors text-xs flex items-center gap-1 font-code"
                title="Copy Phone"
              >
                {copiedField === 'phone' ? (
                  <Check className="w-4 h-4 text-[#4ADE80]" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Location Card */}
            <div className="p-5 rounded-2xl bg-[#0F1426]/75 border border-white/[0.08] backdrop-blur-md flex items-center gap-3.5">
              <div className="p-2.5 rounded-xl bg-[#4ADE80]/10 text-[#4ADE80]">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-[#A0A7C0] font-code">Location</div>
                <div className="text-sm font-semibold text-[#F3F4FF]">
                  {PERSONAL_INFO.location}
                </div>
              </div>
            </div>

            {/* Social Link Cards */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-xl bg-[#0F1426]/75 border border-white/[0.08] hover:border-[#A78BFA]/40 transition-all flex items-center gap-3 group"
              >
                <div className="p-2 rounded-lg bg-[#0077B5]/20 text-[#60A5FA]">
                  <Linkedin className="w-4 h-4" />
                </div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-[#F3F4FF] group-hover:text-[#A78BFA]">
                    LinkedIn
                  </div>
                  <div className="text-[11px] text-[#A0A7C0] truncate">
                    in/sai-losini
                  </div>
                </div>
              </a>

              <a
                href={PERSONAL_INFO.github}
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-xl bg-[#0F1426]/75 border border-white/[0.08] hover:border-[#A78BFA]/40 transition-all flex items-center gap-3 group"
              >
                <div className="p-2 rounded-lg bg-white/10 text-[#F3F4FF]">
                  <Github className="w-4 h-4" />
                </div>
                <div className="truncate">
                  <div className="text-xs font-semibold text-[#F3F4FF] group-hover:text-[#A78BFA]">
                    GitHub
                  </div>
                  <div className="text-[11px] text-[#A0A7C0] truncate">
                    @sailosinik
                  </div>
                </div>
              </a>
            </div>

          </div>

          {/* Contact Form - 7 Columns */}
          <div className="lg:col-span-7 text-left">
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0F1426]/80 border border-white/[0.08] backdrop-blur-md">
              
              {isSubmitted ? (
                <div className="py-8 text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-[#4ADE80]/20 border border-[#4ADE80]/30 text-[#4ADE80] mx-auto flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-[#F3F4FF]">
                    Message Details Validated
                  </h3>
                  
                  <p className="text-sm text-[#A0A7C0] max-w-md mx-auto leading-relaxed">
                    Thank you, <strong className="text-[#F3F4FF]">{formData.name}</strong>. Your message details are ready. Click below to launch your email client and send this message directly to <strong className="text-[#A78BFA]">{PERSONAL_INFO.email}</strong>.
                  </p>

                  <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
                    <a
                      href={mailtoUrl}
                      className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#60A5FA] text-[#080B16] font-semibold text-xs shadow-md shadow-[#A78BFA]/20 hover:opacity-95 transition-all"
                    >
                      <Send className="w-4 h-4" />
                      <span>Open Pre-filled Email</span>
                    </a>

                    <button
                      onClick={() => {
                        setIsSubmitted(false);
                        setFormData({ name: '', email: '', subject: '', message: '' });
                      }}
                      className="px-4 py-2.5 rounded-xl bg-[#161D36] border border-white/[0.08] text-[#A0A7C0] hover:text-white text-xs font-medium transition-colors"
                    >
                      Write Another Note
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <h3 className="text-lg font-bold text-[#F3F4FF] mb-1">
                    Send a Message
                  </h3>
                  <p className="text-xs text-[#A0A7C0] mb-4">
                    Fill out the form below to initiate discussions regarding job opportunities or technical collaboration.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-[#A0A7C0] mb-1.5 font-code">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Hiring Manager"
                        className={`w-full px-4 py-2.5 rounded-xl bg-[#090D1C] border ${
                          errors.name ? 'border-[#EF4444]' : 'border-white/[0.08]'
                        } text-[#F3F4FF] placeholder-[#A0A7C0]/40 text-xs sm:text-sm focus:outline-none focus:border-[#A78BFA] transition-colors`}
                      />
                      {errors.name && (
                        <p className="text-[11px] text-[#EF4444] mt-1 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          <span>{errors.name}</span>
                        </p>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#A0A7C0] mb-1.5 font-code">
                        Your Email *
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="e.g. recruiter@company.com"
                        className={`w-full px-4 py-2.5 rounded-xl bg-[#090D1C] border ${
                          errors.email ? 'border-[#EF4444]' : 'border-white/[0.08]'
                        } text-[#F3F4FF] placeholder-[#A0A7C0]/40 text-xs sm:text-sm focus:outline-none focus:border-[#A78BFA] transition-colors`}
                      />
                      {errors.email && (
                        <p className="text-[11px] text-[#EF4444] mt-1 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          <span>{errors.email}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#A0A7C0] mb-1.5 font-code">
                      Subject *
                    </label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      placeholder="e.g. Python Developer Role at [Company]"
                      className={`w-full px-4 py-2.5 rounded-xl bg-[#090D1C] border ${
                        errors.subject ? 'border-[#EF4444]' : 'border-white/[0.08]'
                      } text-[#F3F4FF] placeholder-[#A0A7C0]/40 text-xs sm:text-sm focus:outline-none focus:border-[#A78BFA] transition-colors`}
                    />
                    {errors.subject && (
                      <p className="text-[11px] text-[#EF4444] mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{errors.subject}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#A0A7C0] mb-1.5 font-code">
                      Message *
                    </label>
                    <textarea
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Write your message here..."
                      className={`w-full px-4 py-2.5 rounded-xl bg-[#090D1C] border ${
                        errors.message ? 'border-[#EF4444]' : 'border-white/[0.08]'
                      } text-[#F3F4FF] placeholder-[#A0A7C0]/40 text-xs sm:text-sm focus:outline-none focus:border-[#A78BFA] transition-colors resize-none`}
                    />
                    {errors.message && (
                      <p className="text-[11px] text-[#EF4444] mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{errors.message}</span>
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#A78BFA] to-[#60A5FA] text-[#080B16] font-bold text-xs sm:text-sm shadow-md shadow-[#A78BFA]/20 hover:opacity-95 transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Validate & Prepare Message</span>
                  </button>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
