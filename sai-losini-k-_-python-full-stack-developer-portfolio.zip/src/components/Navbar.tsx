import React, { useState, useEffect } from 'react';
import { Download, FileText, Menu, X, ArrowUpRight } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface NavbarProps {
  onOpenResumeModal: () => void;
  onOpenGuideModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenResumeModal, onOpenGuideModal }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Projects', href: '#projects' },
    { name: 'Experience', href: '#experience' },
    { name: 'Education', href: '#education' },
    { name: 'Certifications', href: '#certifications' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#080B16]/90 backdrop-blur-md border-b border-white/[0.08] shadow-lg shadow-black/40'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#home"
          onClick={(e) => handleNavClick(e, '#home')}
          className="flex items-center gap-3 group whitespace-nowrap shrink-0 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#A78BFA] rounded-lg p-1"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#A78BFA]/20 via-[#60A5FA]/20 to-[#A78BFA]/10 border border-[#A78BFA]/30 flex items-center justify-center font-code font-bold text-base text-[#A78BFA] group-hover:border-[#A78BFA] transition-colors">
            SL
          </div>
          <div>
            <span className="text-base font-bold tracking-tight text-[#F3F4FF] group-hover:text-white transition-colors block">
              {PERSONAL_INFO.name}
            </span>
            <span className="text-xs text-[#A0A7C0] tracking-normal font-normal block">
              Python Full Stack Developer
            </span>
          </div>
        </a>

        {/* Zone 2: Navigation Links (Clean single-line prose) */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-[#A0A7C0]">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="hover:text-[#F3F4FF] transition-colors whitespace-nowrap shrink-0 relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#A78BFA] hover:after:w-full after:transition-all after:duration-200"
            >
              {link.name}
            </a>
          ))}
        </nav>

        {/* Zone 3: Actions */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenResumeModal}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#F3F4FF] bg-[#161D36] border border-white/[0.08] hover:border-[#A78BFA]/40 hover:text-white rounded-lg transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer"
            title="Preview Resume in browser"
          >
            <FileText className="w-3.5 h-3.5 text-[#A78BFA]" />
            <span>Preview CV</span>
          </button>

          <a
            href={PERSONAL_INFO.resumePath}
            download="Sai_Losini_K_Resume.pdf"
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#080B16] bg-gradient-to-r from-[#A78BFA] to-[#60A5FA] hover:opacity-95 rounded-lg transition-all duration-200 shadow-md shadow-[#A78BFA]/20 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Resume</span>
          </a>

          <button
            onClick={onOpenGuideModal}
            className="text-xs text-[#A0A7C0] hover:text-[#F3F4FF] px-2 py-1 rounded transition-colors hidden xl:inline-flex items-center gap-1 border border-white/[0.05]"
            title="Project Setup & Customization Guide"
          >
            <span>Guide</span>
            <ArrowUpRight className="w-3 h-3 text-[#A78BFA]" />
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-[#161D36] text-[#F3F4FF] border border-white/[0.08] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#A78BFA]"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0B0F20] border-b border-white/[0.1] px-6 py-6 shadow-2xl transition-all">
          <nav className="flex flex-col gap-4 text-sm font-medium text-[#A0A7C0]">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="py-1.5 hover:text-[#A78BFA] transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>
          <div className="mt-6 pt-5 border-t border-white/[0.08] flex flex-col gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenResumeModal();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#F3F4FF] bg-[#161D36] border border-white/[0.1] rounded-lg"
            >
              <FileText className="w-4 h-4 text-[#A78BFA]" />
              <span>Preview Resume PDF</span>
            </button>
            <a
              href={PERSONAL_INFO.resumePath}
              download="Sai_Losini_K_Resume.pdf"
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#080B16] bg-gradient-to-r from-[#A78BFA] to-[#60A5FA] rounded-lg"
            >
              <Download className="w-4 h-4" />
              <span>Download Resume PDF</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
