import React, { useState } from 'react';
import { ExternalLink, Github, Layers, CheckCircle2, Award, Sparkles, X, Terminal, ArrowRight } from 'lucide-react';
import { PROJECTS, Project, PERSONAL_INFO } from '../data/portfolioData';

export const Projects: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <section id="projects" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-4 text-left">
          <div>
            <p className="text-xs uppercase tracking-widest font-semibold text-[#A78BFA] mb-2 font-code">
              03. Key Technical Initiatives
            </p>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#F3F4FF] tracking-tight">
              Featured Projects
            </h2>
            <p className="text-[#A0A7C0] text-sm sm:text-base mt-2 max-w-xl">
              Real-world engineering initiatives featuring full-stack development, automated data pipelines, and a published patent.
            </p>
          </div>

          <a
            href={PERSONAL_INFO.github}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0F1426] border border-white/[0.08] hover:border-[#A78BFA]/40 text-xs font-semibold text-[#F3F4FF] transition-all self-start md:self-auto"
          >
            <Github className="w-4 h-4 text-[#A78BFA]" />
            <span>Explore All Repositories</span>
          </a>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-left">
          {PROJECTS.map((project, idx) => (
            <div
              key={project.id}
              className="flex flex-col justify-between p-7 rounded-2xl bg-[#0F1426]/75 border border-white/[0.08] hover:border-[#A78BFA]/40 transition-all duration-300 backdrop-blur-md group hover:shadow-xl hover:shadow-[#A78BFA]/10 relative"
            >
              {/* Optional Patent Pill/Badge */}
              {project.isPatent && (
                <div className="absolute -top-3 right-6 px-3 py-1 rounded-full bg-gradient-to-r from-[#A78BFA] to-[#60A5FA] text-[#080B16] text-[11px] font-bold shadow-md shadow-[#A78BFA]/20 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  <span>Patent Filed</span>
                </div>
              )}

              <div>
                {/* Category & Index */}
                <div className="flex items-center justify-between text-xs text-[#A0A7C0] mb-3 font-code">
                  <span>{project.category}</span>
                  <span>0{idx + 1}</span>
                </div>

                {/* Project Title */}
                <h3 className="text-xl font-bold text-[#F3F4FF] group-hover:text-white transition-colors">
                  {project.title}
                </h3>

                {/* Tagline */}
                <p className="text-xs text-[#A78BFA] mt-1 font-medium">
                  {project.tagline}
                </p>

                {/* Summary */}
                <p className="text-sm text-[#A0A7C0] mt-3.5 leading-relaxed">
                  {project.description}
                </p>

                {/* Key Features Bullet List */}
                <div className="mt-5 space-y-2">
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-[#F3F4FF]/70 font-code block">
                    Key Highlights:
                  </span>
                  {project.keyFeatures.slice(0, 3).map((feature, fIdx) => (
                    <div key={fIdx} className="flex items-start gap-2 text-xs text-[#A0A7C0] leading-snug">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#4ADE80] shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Technologies */}
                <div className="mt-6 pt-5 border-t border-white/[0.06] flex flex-wrap gap-1.5">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 rounded-md bg-[#090D1C] border border-white/[0.06] text-[11px] font-code text-[#E2E8F0]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 pt-4 border-t border-white/[0.06] flex items-center justify-between gap-3">
                <button
                  onClick={() => setSelectedProject(project)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#A78BFA] hover:text-white transition-colors cursor-pointer"
                >
                  <span>Architecture Deep Dive</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <div className="flex items-center gap-2">
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-lg bg-[#161D36] border border-white/[0.08] hover:border-[#A78BFA]/50 text-[#F3F4FF] hover:text-[#A78BFA] transition-colors"
                    title="View GitHub Repository"
                  >
                    <Github className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Project Detail Modal */}
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
            <div className="w-full max-w-2xl bg-[#0D1224] border border-[#A78BFA]/30 rounded-2xl shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto text-left relative">
              
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-5 right-5 p-2 rounded-lg bg-[#161D36] text-[#A0A7C0] hover:text-white hover:bg-[#1E2646] transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-xs font-code text-[#A78BFA] mb-2">
                <span>{selectedProject.category}</span>
                {selectedProject.isPatent && (
                  <>
                    <span>·</span>
                    <span className="text-[#4ADE80]">{selectedProject.patentDetails}</span>
                  </>
                )}
              </div>

              <h3 className="text-2xl font-bold text-[#F3F4FF]">
                {selectedProject.title}
              </h3>

              <p className="text-sm text-[#A0A7C0] mt-1 font-medium">
                {selectedProject.tagline}
              </p>

              <div className="my-5 p-4 rounded-xl bg-[#090D1C] border border-white/[0.06] text-sm text-[#E2E8F0] leading-relaxed">
                {selectedProject.description}
              </div>

              {/* Architecture Blueprint breakdown */}
              <div className="space-y-3 mb-6">
                <h4 className="text-xs uppercase tracking-wider font-semibold text-[#A78BFA] font-code flex items-center gap-1.5">
                  <Layers className="w-4 h-4" />
                  <span>Technical Architecture & Implementation</span>
                </h4>
                <div className="space-y-2">
                  {selectedProject.architectureDetails.map((step, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-[#161D36]/60 border border-white/[0.05] text-xs text-[#A0A7C0] flex items-start gap-2.5">
                      <span className="font-code font-bold text-[#60A5FA] shrink-0 mt-0.5">
                        0{idx + 1}
                      </span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technologies */}
              <div className="mb-6">
                <h4 className="text-xs uppercase tracking-wider font-semibold text-[#F3F4FF]/80 font-code mb-2">
                  Technologies Applied
                </h4>
                <div className="flex flex-wrap gap-2">
                  {selectedProject.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 rounded-lg bg-[#161D36] border border-white/[0.08] text-xs font-code text-[#A78BFA]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Modal footer with links */}
              <div className="pt-4 border-t border-white/[0.08] flex items-center justify-between">
                <a
                  href={selectedProject.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#A78BFA] text-[#080B16] font-semibold text-xs hover:bg-[#A78BFA]/90 transition-colors"
                >
                  <Github className="w-4 h-4" />
                  <span>Open GitHub Repo</span>
                </a>

                <button
                  onClick={() => setSelectedProject(null)}
                  className="px-4 py-2 rounded-xl bg-[#161D36] text-xs text-[#A0A7C0] hover:text-[#F3F4FF] transition-colors"
                >
                  Close
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
