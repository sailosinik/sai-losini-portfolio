import React from 'react';
import { ArrowUp, Github, Linkedin, Mail, Heart } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-white/[0.08] bg-[#060812] py-12 text-[#A0A7C0] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
        
        {/* Left: Brand & Title */}
        <div className="text-center md:text-left">
          <div className="font-bold text-[#F3F4FF] text-sm tracking-tight">
            {PERSONAL_INFO.name}
          </div>
          <div className="text-xs text-[#A78BFA] mt-0.5">
            {PERSONAL_INFO.title} · Chennai, India
          </div>
          <div className="text-[11px] text-[#A0A7C0]/70 mt-2">
            Built with modern React, TypeScript & Tailwind CSS.
          </div>
        </div>

        {/* Center: Social Links */}
        <div className="flex items-center gap-4">
          <a
            href={PERSONAL_INFO.github}
            target="_blank"
            rel="noreferrer"
            className="p-2 rounded-lg bg-[#0F1426] border border-white/[0.08] hover:border-[#A78BFA]/40 hover:text-[#F3F4FF] transition-colors"
            title="GitHub"
          >
            <Github className="w-4 h-4" />
          </a>

          <a
            href={PERSONAL_INFO.linkedin}
            target="_blank"
            rel="noreferrer"
            className="p-2 rounded-lg bg-[#0F1426] border border-white/[0.08] hover:border-[#60A5FA]/40 hover:text-[#F3F4FF] transition-colors"
            title="LinkedIn"
          >
            <Linkedin className="w-4 h-4" />
          </a>

          <a
            href={`mailto:${PERSONAL_INFO.email}`}
            className="p-2 rounded-lg bg-[#0F1426] border border-white/[0.08] hover:border-[#4ADE80]/40 hover:text-[#F3F4FF] transition-colors"
            title="Email"
          >
            <Mail className="w-4 h-4" />
          </a>
        </div>

        {/* Right: Copyright & Back to Top */}
        <div className="flex items-center gap-4 text-center md:text-right">
          <div>
            © {new Date().getFullYear()} {PERSONAL_INFO.name}. All rights reserved.
          </div>

          <button
            onClick={scrollToTop}
            className="p-2 rounded-lg bg-[#0F1426] border border-white/[0.08] hover:border-[#A78BFA]/40 text-[#A0A7C0] hover:text-[#F3F4FF] transition-colors cursor-pointer"
            title="Back to Top"
            aria-label="Scroll back to top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>
    </footer>
  );
};
