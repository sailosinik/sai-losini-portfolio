import React from 'react';
import { EXPERIENCES } from '../data/portfolioData';
import { Briefcase, Calendar, MapPin, CheckCircle, Cpu } from 'lucide-react';

export const Experience: React.FC = () => {
  return (
    <section id="experience" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-14 text-left">
          <p className="text-xs uppercase tracking-widest font-semibold text-[#A78BFA] mb-2 font-code">
            04. Practical Industry Experience
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#F3F4FF] tracking-tight">
            Internships & Work History
          </h2>
          <p className="text-[#A0A7C0] text-sm sm:text-base mt-2 max-w-xl">
            Hands-on manufacturing, testing, and systems experience gained across Tier-1 automotive electronics environments.
          </p>
        </div>

        {/* Vertical Timeline */}
        <div className="relative border-l border-white/[0.1] ml-4 sm:ml-8 space-y-12 text-left">
          {EXPERIENCES.map((exp, idx) => (
            <div key={exp.id} className="relative pl-8 sm:pl-10 group">
              
              {/* Timeline marker node */}
              <div className="absolute -left-[17px] top-1.5 w-8 h-8 rounded-full bg-[#0D1224] border border-[#A78BFA] flex items-center justify-center text-[#A78BFA] group-hover:scale-110 transition-transform">
                <Briefcase className="w-3.5 h-3.5" />
              </div>

              {/* Experience Card */}
              <div className="p-6 sm:p-7 rounded-2xl bg-[#0F1426]/75 border border-white/[0.08] hover:border-[#A78BFA]/30 transition-all duration-300 backdrop-blur-md">
                
                {/* Header metadata */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-white/[0.06]">
                  <div>
                    <h3 className="text-xl font-bold text-[#F3F4FF]">
                      {exp.role}
                    </h3>
                    <div className="text-sm font-semibold text-[#A78BFA] mt-0.5">
                      {exp.company}
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-[#A0A7C0] font-code">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#60A5FA]" />
                      <span>{exp.period}</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#4ADE80]" />
                      <span>{exp.location}</span>
                    </span>
                  </div>
                </div>

                {/* Responsibilities list */}
                <div className="space-y-2.5 mb-6">
                  {exp.description.map((item, dIdx) => (
                    <div key={dIdx} className="flex items-start gap-2.5 text-sm text-[#A0A7C0] leading-relaxed">
                      <CheckCircle className="w-4 h-4 text-[#4ADE80] shrink-0 mt-1" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>

                {/* Technologies / Focus Areas */}
                <div className="pt-4 border-t border-white/[0.05] flex flex-wrap gap-2 items-center">
                  <span className="text-xs text-[#F3F4FF]/70 font-code mr-1">Domains:</span>
                  {exp.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 rounded-md bg-[#090D1C] border border-white/[0.05] text-[11px] font-code text-[#E2E8F0]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
