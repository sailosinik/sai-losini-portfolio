import React from 'react';
import { EDUCATION } from '../data/portfolioData';
import { GraduationCap, Calendar, Award, BookOpen } from 'lucide-react';

export const Education: React.FC = () => {
  return (
    <section id="education" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-14 text-left">
          <p className="text-xs uppercase tracking-widest font-semibold text-[#A78BFA] mb-2 font-code">
            05. Academic Qualifications
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#F3F4FF] tracking-tight">
            Education
          </h2>
          <p className="text-[#A0A7C0] text-sm sm:text-base mt-2 max-w-xl">
            Formal engineering foundations and strong academic track record from premier educational institutions.
          </p>
        </div>

        {/* Education Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
          {EDUCATION.map((edu, idx) => (
            <div
              key={idx}
              className="p-7 sm:p-8 rounded-2xl bg-[#0F1426]/75 border border-white/[0.08] hover:border-[#A78BFA]/30 transition-all duration-300 backdrop-blur-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-4 pb-4 mb-4 border-b border-white/[0.06]">
                  <div className="p-3 rounded-xl bg-[#161D36] border border-white/[0.08] text-[#A78BFA] shrink-0">
                    <GraduationCap className="w-6 h-6" />
                  </div>

                  {edu.score && (
                    <div className="text-right">
                      <div className="text-xl font-bold font-code text-[#4ADE80] tabular-nums">
                        {edu.score}
                      </div>
                      <div className="text-[11px] text-[#A0A7C0] uppercase tracking-wider font-code">
                        {edu.scoreLabel}
                      </div>
                    </div>
                  )}
                </div>

                <h3 className="text-xl font-bold text-[#F3F4FF]">
                  {edu.degree}
                </h3>

                <div className="text-sm font-semibold text-[#A78BFA] mt-1">
                  {edu.institution}
                </div>

                <div className="flex items-center gap-2 text-xs text-[#A0A7C0] font-code mt-2">
                  <Calendar className="w-3.5 h-3.5 text-[#60A5FA]" />
                  <span>{edu.period}</span>
                </div>

                <p className="text-sm text-[#A0A7C0] mt-4 leading-relaxed">
                  {edu.details}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-white/[0.04] flex items-center justify-between text-xs text-[#A0A7C0]">
                <span>Status: Completed / In Progress</span>
                <span className="text-[#60A5FA]">Verified Credential</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
