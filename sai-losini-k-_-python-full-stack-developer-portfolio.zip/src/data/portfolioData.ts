export interface Project {
  id: string;
  title: string;
  category: string;
  tagline: string;
  technologies: string[];
  description: string;
  keyFeatures: string[];
  githubUrl: string;
  demoUrl?: string;
  isPatent?: boolean;
  patentDetails?: string;
  architectureDetails: string[];
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  location: string;
  period: string;
  year: string;
  description: string[];
  technologies: string[];
}

export interface EducationItem {
  degree: string;
  institution: string;
  period: string;
  score?: string;
  scoreLabel?: string;
  details: string;
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  type: 'award' | 'certification' | 'patent';
  dateOrYear?: string;
  details: string;
  badge?: string;
  link?: string;
}

export const PERSONAL_INFO = {
  name: "Sai Losini K",
  title: "Python Full Stack Developer",
  location: "Chennai, Tamil Nadu, India",
  phone: "+91 8015729808",
  email: "sailosinik665@gmail.com",
  linkedin: "https://linkedin.com/in/sai-losini",
  linkedinHandle: "linkedin.com/in/sai-losini",
  github: "https://github.com/sailosinik",
  githubHandle: "github.com/sailosinik",
  resumePath: "/Sai_Losini_K_Resume.pdf",
  resumeOriginalPath: "/assets/aistudio/sailosinik_resume_._3ffcaf76.pdf",
  bio: "Aspiring Software Developer with hands-on experience in Python, SQL, OOP, backend development, and AWS. Skilled in building full-stack applications and practical software solutions using Flask, SQLAlchemy, PostgreSQL, and Python. Strong problem-solving foundation with technical projects, hackathon achievements, a published patent, and hands-on internship experience.",
  careerGoal: "To build a high-impact career in software development and contribute to real-world technology projects that scale.",
  status: "Available for Entry-Level & Fresher Software Developer Roles",
};

export const SKILL_CATEGORIES = [
  {
    category: "Languages & Concepts",
    skills: [
      { name: "Python", highlight: "Primary backend language, OOP, data processing, automation" },
      { name: "SQL", highlight: "Complex queries, joins, window functions, schema design" },
      { name: "OOP", highlight: "Object-oriented design patterns, modularity, abstraction" },
      { name: "Data Structures", highlight: "Arrays, trees, hash maps, algorithms, optimization" },
      { name: "ETL Pipeline Design", highlight: "Extract, Transform, Load processes and data pipelines" },
    ],
  },
  {
    category: "Web & Backend",
    skills: [
      { name: "Flask", highlight: "Lightweight Python web framework, blueprint routing, REST APIs" },
      { name: "SQLAlchemy", highlight: "ORM modeling, migrations, session management" },
      { name: "REST APIs", highlight: "HTTP methods, JSON serialization, API architecture" },
      { name: "JavaScript", highlight: "ES6+, DOM manipulation, asynchronous programming" },
      { name: "HTML5 & CSS3", highlight: "Semantic layout, responsive design, modern UI styling" },
    ],
  },
  {
    category: "Databases",
    skills: [
      { name: "PostgreSQL", highlight: "Relational database management, indexing, constraints" },
      { name: "MySQL", highlight: "Relational modeling, SQL queries, transactions" },
      { name: "SQLite", highlight: "Embedded lightweight database for rapid prototyping" },
    ],
  },
  {
    category: "Cloud, BI & Tools",
    skills: [
      { name: "AWS", highlight: "S3, EC2, Lambda, IAM, DynamoDB cloud infrastructure" },
      { name: "Power BI", highlight: "Data visualization, business intelligence dashboards, KPI metrics" },
      { name: "Data Analysis", highlight: "Data cleaning, aggregation, exploratory data insights" },
      { name: "Git & GitHub", highlight: "Version control, branching strategies, collaborative workflows" },
    ],
  },
  {
    category: "Soft Skills",
    skills: [
      { name: "Problem Solving", highlight: "Analytical thinking and algorithmic problem resolution" },
      { name: "Communication", highlight: "Clear documentation, team coordination, technical presentations" },
      { name: "Teamwork & Collaboration", highlight: "Hackathon teamwork and cross-functional project execution" },
      { name: "Leadership", highlight: "Hackathon project leadership and technical initiative" },
      { name: "Time Management", highlight: "Milestone planning and sprint delivery under deadlines" },
    ],
  },
];

export const PROJECTS: Project[] = [
  {
    id: "sales-etl",
    title: "Sales Data Automation ETL",
    category: "Data Engineering / BI",
    tagline: "End-to-End Automated Data Pipeline & Live BI Analytics Dashboard",
    technologies: ["Python", "PostgreSQL", "Power BI", "Data Analysis", "ETL"],
    description: "Architected an end-to-end ETL pipeline extracting, transforming, and loading sales data into PostgreSQL, automating profit calculations and powering a live Power BI dashboard with regional, category, and KPI insights.",
    keyFeatures: [
      "Automated extraction and data cleaning of high-volume sales transaction datasets",
      "Robust data transformation layer computing profit margins, discounts, and regional aggregations",
      "Optimized PostgreSQL schema with relational constraints and indexing for fast query performance",
      "Interactive Power BI dashboard delivering real-time executive KPIs, category breakdowns, and geospatial sales trends",
    ],
    githubUrl: "https://github.com/sailosinik",
    architectureDetails: [
      "Data Ingestion: Python scripts extract raw tabular records from heterogeneous data sources",
      "Transformation Engine: Pandas/Python routines cleanse nulls, normalize datatypes, and compute business metrics",
      "Relational Warehouse: Cleaned records are batch-loaded into PostgreSQL relational staging and production tables",
      "Presentation Layer: Power BI communicates with PostgreSQL via direct connection to render automated analytics",
    ],
  },
  {
    id: "job-tracker",
    title: "Job Application Tracker",
    category: "Full Stack Web App",
    tagline: "Comprehensive Recruitment Workflow Management System",
    technologies: ["Python", "Flask", "SQLAlchemy", "SQLite", "Bootstrap", "JavaScript", "HTML/CSS"],
    description: "Architected a full-stack Flask + SQLAlchemy web application for managing job applications with recruitment-stage tracking, company-specific detail views, and a responsive HTML/CSS/Bootstrap/JavaScript frontend.",
    keyFeatures: [
      "End-to-end recruitment lifecycle tracker (Applied, Screening, Technical Interview, HR, Offer, Archived)",
      "Company-specific detail views tracking contact recruiters, interview dates, and notes",
      "Relational ORM data models implemented via Flask-SQLAlchemy with clean database migrations",
      "Intuitive and responsive user interface built with Bootstrap 5 and dynamic JavaScript interactions",
    ],
    githubUrl: "https://github.com/sailosinik",
    architectureDetails: [
      "Backend: Python Flask application structuring modular routes and REST endpoints",
      "Data Layer: SQLAlchemy ORM mapping application models to an SQLite database with structured schemas",
      "Frontend: Responsive Bootstrap 5 UI enhanced with JavaScript for dynamic status updates without page reloads",
      "Validation: Form sanitization and error-handling utilities for consistent data entry",
    ],
  },
  {
    id: "smart-recycling",
    title: "Smart Plastic Recycling Machine",
    category: "IoT & Hardware-Software System",
    tagline: "Solar-Powered Automated Sorting System with Computer Vision & Cloud Telemetry",
    technologies: ["Python", "Raspberry Pi", "IoT", "Computer Vision (OCR)", "Edge Detection", "Sensors"],
    description: "Designed a solar-powered, IoT-enabled recycling system using image processing (OCR, edge detection), load-cell sensors, and a QR-based incentive mechanism for automated sorting with real-time cloud monitoring.",
    isPatent: true,
    patentDetails: "Official Patent Publication filed on the Indian Patent Platform",
    keyFeatures: [
      "Computer vision pipeline leveraging OCR and edge detection algorithms for automated plastic type identification",
      "Load-cell sensors integration for precise material weight measurement and classification",
      "QR-code based digital reward incentive mechanism rewarding citizens upon successful recycling deposits",
      "Solar-powered autonomous hardware architecture with low-power Raspberry Pi edge compute and cloud telemetry",
    ],
    githubUrl: "https://github.com/sailosinik",
    architectureDetails: [
      "Vision Pipeline: Python computer vision modules inspect packaging markings using OCR and contour edge detection",
      "Hardware Controller: Raspberry Pi orchestrates servo actuators, stepper motors, and load-cell sensory inputs",
      "Incentive Flow: Generates dynamic QR tokens verified against user accounts to encourage recycling participation",
      "Cloud Integration: Real-time telemetry monitoring machine capacity, battery levels, and deposit statistics",
    ],
  },
];

export const EXPERIENCES: Experience[] = [
  {
    id: "gt-electronics",
    role: "Automotive Electronics Intern",
    company: "GT Electronic India Pvt Ltd",
    location: "Chennai, India",
    period: "2025",
    year: "2025",
    description: [
      "Executed testing, quality control, and PCB assembly for automotive electronic systems, ensuring compliance and product reliability.",
      "Monitored manufacturing processes systematically to identify operational inefficiencies and enhance production throughput.",
      "Collaborated with senior engineers on testing protocols, diagnostic routines, and quality assurance standards.",
    ],
    technologies: ["Automotive Electronics", "PCB Assembly", "Testing & Quality Control", "Process Optimization", "Reliability Engineering"],
  },
  {
    id: "kyungshin-motherson",
    role: "Automotive Electronics Intern",
    company: "Kyungshin Industrial Motherson Pvt. Ltd. (KIML)",
    location: "Chennai, India",
    period: "2025",
    year: "2025",
    description: [
      "Worked with Junction Block manufacturing, PCB assembly, precision soldering, and component integration.",
      "Gained comprehensive exposure to automated industrial machines, high-precision quality inspection, and MES (Manufacturing Execution Systems).",
      "Enforced strict ESD (Electrostatic Discharge) practices and supported automotive wiring harness validation.",
    ],
    technologies: ["MES Systems", "Automated Machinery", "Junction Block Manufacturing", "ESD Practices", "Automotive Wiring Harnesses"],
  },
];

export const EDUCATION: EducationItem[] = [
  {
    degree: "B.E. in Instrumentation & Control Engineering",
    institution: "Sri Sairam Engineering College",
    period: "09/2022 – 05/2026",
    score: "8.16 / 10.00",
    scoreLabel: "CGPA",
    details: "Focusing on analytical problem-solving, microcontrollers, control systems, and software systems. Transitioned core analytical skills toward full-stack software development and data engineering.",
  },
  {
    degree: "Higher Secondary Certificate (HSC) & SSLC",
    institution: "St. Joseph's Girls Higher Secondary School",
    period: "Secondary & Higher Secondary Education",
    details: "Built strong foundational background in Mathematics, Physics, and Computer Sciences with academic excellence.",
  },
];

export const HONORS_AND_CERTIFICATIONS: Certification[] = [
  {
    id: "patent-publication",
    title: "Official Patent Publication",
    issuer: "Indian Patent Platform",
    type: "patent",
    details: "Official Patent Publication filed for the Smart Plastic Recycling Machine (Solar-powered IoT recycling system with computer vision and automated sorting).",
    badge: "Intellectual Property",
  },
  {
    id: "hack-summit",
    title: "Best Innovation Award",
    issuer: "Hack Summit 5.0 (Team Aarush, SRM College)",
    type: "award",
    details: "Recognized with ₹10,000 cash prize for delivering innovative, practical technology architecture and problem solving.",
    badge: "₹10,000 Prize",
  },
  {
    id: "hacklite",
    title: "1st Prize Winner",
    issuer: "Hacklite Hackathon, St. Joseph's College of Engineering",
    type: "award",
    details: "Awarded First Place for innovative engineering, teamwork, and rapid software solution prototype delivery.",
    badge: "1st Prize",
  },
  {
    id: "hackerrank-swe",
    title: "Software Engineer Certificate",
    issuer: "HackerRank",
    type: "certification",
    details: "Standardized certification validating competency in data structures, algorithms, problem solving, and software engineering principles.",
    badge: "HackerRank Verified",
  },
  {
    id: "hackerrank-sql",
    title: "SQL Certification",
    issuer: "HackerRank",
    type: "certification",
    details: "Demonstrated proficiency in writing advanced SQL queries, joins, subqueries, aggregations, and data manipulations.",
    badge: "HackerRank Verified",
  },
];

export const LANGUAGES = [
  { language: "English", proficiency: "Native / Full Professional Proficiency" },
  { language: "Tamil", proficiency: "Native / Bilingual Proficiency" },
];

export const CODE_SNIPPETS = {
  etl: {
    filename: "sales_pipeline.py",
    language: "python",
    code: `import psycopg2
import pandas as pd
from datetime import datetime

class SalesETLPipeline:
    def __init__(self, db_config):
        self.conn = psycopg2.connect(**db_config)
        self.cursor = self.conn.cursor()

    def extract(self, source_path: str) -> pd.DataFrame:
        """Extract sales transactions from source CSV/API"""
        raw_df = pd.read_csv(source_path)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Extracted {len(raw_df)} records")
        return raw_df

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean data, calculate profit margins and normalize"""
        df = df.dropna(subset=['order_id', 'amount'])
        df['net_profit'] = df['amount'] * (1 - df['discount_rate']) - df['cost']
        df['margin_pct'] = (df['net_profit'] / df['amount']) * 100
        return df

    def load(self, df: pd.DataFrame):
        """Batch load cleaned records into PostgreSQL warehouse"""
        query = """
            INSERT INTO sales_analytics (order_id, amount, net_profit, margin_pct)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (order_id) DO UPDATE SET net_profit = EXCLUDED.net_profit;
        """
        records = df[['order_id', 'amount', 'net_profit', 'margin_pct']].to_numpy()
        self.cursor.executemany(query, records)
        self.conn.commit()
        print("Data successfully committed to PostgreSQL database.")`,
  },
  flask: {
    filename: "app.py",
    language: "python",
    code: `from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///job_tracker.db'
db = SQLAlchemy(app)

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(50), default='Applied')
    applied_date = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)

@app.route('/api/applications', methods=['POST'])
def add_application():
    data = request.json
    new_app = Application(
        company=data['company'],
        role=data['role'],
        status=data.get('status', 'Applied'),
        notes=data.get('notes', '')
    )
    db.session.add(new_app)
    db.session.commit()
    return jsonify({"message": "Application tracked successfully", "id": new_app.id}), 201`,
  },
  sql: {
    filename: "schema.sql",
    language: "sql",
    code: `-- Analytical Warehouse Schema for Regional Sales
CREATE TABLE IF NOT EXISTS sales_analytics (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(64) UNIQUE NOT NULL,
    customer_region VARCHAR(64) NOT NULL,
    product_category VARCHAR(64) NOT NULL,
    amount NUMERIC(12, 2) NOT NULL,
    cost NUMERIC(12, 2) NOT NULL,
    net_profit NUMERIC(12, 2) NOT NULL,
    margin_pct NUMERIC(5, 2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sales_region ON sales_analytics (customer_region);
CREATE INDEX idx_sales_category ON sales_analytics (product_category);

-- Aggregated KPI query for Power BI Dashboard
SELECT 
    customer_region,
    product_category,
    COUNT(order_id) AS total_orders,
    SUM(amount) AS gross_revenue,
    SUM(net_profit) AS total_profit,
    ROUND(AVG(margin_pct), 2) AS avg_margin
FROM sales_analytics
GROUP BY customer_region, product_category
ORDER BY total_profit DESC;`,
  },
};
