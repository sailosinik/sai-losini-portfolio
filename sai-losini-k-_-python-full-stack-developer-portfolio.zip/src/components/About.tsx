import React from 'react';
import { Award, BookOpen, Code2, Cpu, Globe, Rocket, Terminal, ShieldCheck } from 'lucide-react';
import { PERSONAL_INFO, LANGUAGES } from '../data/portfolioData';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-14 text-left">
          <p className="text-xs uppercase tracking-widest font-semibold text-[#A78BFA] mb-2 font-code">
            01. Background & Journey
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#F3F4FF] tracking-tight">
            About Me
          </h2>
          <p className="text-[#A0A7C0] text-sm sm:text-base mt-2 max-w-2xl">
            A software developer with a disciplined engineering background, hands-on backend expertise, and a published hardware-software patent.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Main Narrative - 7 Columns */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="p-6 sm:p-8 rounded-2xl bg-[#0F1426]/70 border border-white/[0.08] backdrop-blur-md space-y-4">
              <h3 className="text-xl font-semibold text-[#F3F4FF]">
                Engineering Mindset Applied to Software Development
              </h3>
              
              <p className="text-[#A0A7C0] text-sm sm:text-base leading-relaxed">
                Currently completing my <strong className="text-[#F3F4FF] font-semibold">B.E. in Instrumentation & Control Engineering</strong> (CGPA: 8.16/10.00) at Sri Sairam Engineering College, I discovered my passion for full-stack software development through hands-on technical projects and algorithmic problem solving.
              </p>

              <p className="text-[#A0A7C0] text-sm sm:text-base leading-relaxed">
                My foundation in engineering systems gave me deep respect for architecture reliability, data flow, and efficiency. I translated these principles directly into modern software engineering—building full-stack web applications with <span className="text-[#A78BFA] font-medium">Python, Flask, and SQLAlchemy</span>, engineering automated ETL pipelines for <span className="text-[#60A5FA] font-medium">PostgreSQL and Power BI</span>, and architecting IoT solutions on <span className="text-[#4ADE80] font-medium">Raspberry Pi</span>.
              </p>

              <p className="text-[#A0A7C0] text-sm sm:text-base leading-relaxed">
                During 2025, my internships at <span className="text-[#F3F4FF] font-medium">GT Electronic India</span> and <span className="text-[#F3F4FF] font-medium">Kyungshin Industrial Motherson</span> provided practical exposure to manufacturing execution systems (MES), automated machines, and rigorous testing protocols—instilling the discipline required for production-ready code.
              </p>
            </div>

            {/* Core Values / Career Orientation */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-xl bg-[#0D1224]/80 border border-white/[0.06] flex items-start gap-3.5">
                <div className="p-2 rounded-lg bg-[#A78BFA]/10 text-[#A78BFA] shrink-0 mt-0.5">
                  <Terminal className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-[#F3F4FF]">Practical Software Solutions</h4>
                  <p className="text-xs text-[#A0A7C0] mt-1 leading-relaxed">
                    Focused on building robust backend APIs, clean relational schemas, and responsive user interfaces that solve tangible workflow bottlenecks.
                  </p>
                </div>
              </div>

              <div className="p-5 rounded-xl bg-[#0D1224]/80 border border-white/[0.06] flex items-start gap-3.5">
                <div className="p-2 rounded-lg bg-[#60A5FA]/10 text-[#60A5FA] shrink-0 mt-0.5">
                  <Rocket className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-[#F3F4FF]">Rapid Problem Solver</h4>
                  <p className="text-xs text-[#A0A7C0] mt-1 leading-relaxed">
                    Recognized with 1st Prize at Hacklite and Best Innovation at Hack Summit 5.0 (₹10,000 cash prize) for rapid collaborative prototype delivery.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Facts & Linguistic Profile - 5 Columns */}
          <div className="lg:col-span-5 space-y-6 text-left">
            
            {/* Quick Profile Snapshot */}
            <div className="p-6 rounded-2xl bg-[#0F1426]/70 border border-white/[0.08] backdrop-blur-md space-y-4">
              <h3 className="text-sm uppercase tracking-wider font-semibold text-[#A78BFA] font-code">
                Profile Highlights
              </h3>

              <div className="space-y-3.5 text-xs sm:text-sm">
                <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.06]">
                  <span className="text-[#A0A7C0]">Name</span>
                  <span className="font-semibold text-[#F3F4FF]">{PERSONAL_INFO.name}</span>
                </div>

                <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.06]">
                  <span className="text-[#A0A7C0]">Primary Role</span>
                  <span className="font-semibold text-[#A78BFA]">{PERSONAL_INFO.title}</span>
                </div>

                <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.06]">
                  <span className="text-[#A0A7C0]">Degree</span>
                  <span className="font-medium text-[#F3F4FF] text-right">B.E. Instrumentation & Control</span>
                </div>

                <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.06]">
                  <span className="text-[#A0A7C0]">Institution</span>
                  <span className="font-medium text-[#F3F4FF] text-right">Sri Sairam Engineering College</span>
                </div>

                <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.06]">
                  <span className="text-[#A0A7C0]">Academic Standing</span>
                  <span className="font-semibold text-[#4ADE80] font-code">CGPA 8.16 / 10.00</span>
                </div>

                <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.06]">
                  <span className="text-[#A0A7C0]">Location</span>
                  <span className="font-medium text-[#F3F4FF]">{PERSONAL_INFO.location}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[#A0A7C0]">Patent Status</span>
                  <span className="font-medium text-[#60A5FA]">Official Patent Publication Filed</span>
                </div>
              </div>
            </div>

            {/* Languages Spoken (From resume) */}
            <div className="p-6 rounded-2xl bg-[#0F1426]/70 border border-white/[0.08] backdrop-blur-md">
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-4 h-4 text-[#A78BFA]" />
                <h4 className="text-sm uppercase tracking-wider font-semibold text-[#F3F4FF] font-code">
                  Languages
                </h4>
              </div>

              <div className="space-y-2.5">
                {LANGUAGES.map((lang) => (
                  <div key={lang.language} className="flex items-center justify-between text-xs sm:text-sm">
                    <span className="font-medium text-[#F3F4FF]">{lang.language}</span>
                    <span className="text-[#A0A7C0]">{lang.proficiency}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
