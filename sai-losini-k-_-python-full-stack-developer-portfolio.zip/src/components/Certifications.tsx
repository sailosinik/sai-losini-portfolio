import React from 'react';
import { HONORS_AND_CERTIFICATIONS } from '../data/portfolioData';
import { Trophy, Award, FileCode, CheckCircle, ExternalLink, ShieldCheck } from 'lucide-react';

export const Certifications: React.FC = () => {
  return (
    <section id="certifications" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-14 text-left">
          <p className="text-xs uppercase tracking-widest font-semibold text-[#A78BFA] mb-2 font-code">
            06. Recognitions & Credentials
          </p>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#F3F4FF] tracking-tight">
            Honors & Certifications
          </h2>
          <p className="text-[#A0A7C0] text-sm sm:text-base mt-2 max-w-xl">
            Verified technical certifications, hackathon victories, and official patent intellectual property filings.
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
          {HONORS_AND_CERTIFICATIONS.map((item) => {
            const isAward = item.type === 'award';
            const isPatent = item.type === 'patent';

            return (
              <div
                key={item.id}
                className="p-6 rounded-2xl bg-[#0F1426]/75 border border-white/[0.08] hover:border-[#A78BFA]/30 transition-all duration-300 backdrop-blur-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 pb-4 mb-4 border-b border-white/[0.06]">
                    <div
                      className={`p-2.5 rounded-xl border ${
                        isPatent
                          ? 'bg-[#60A5FA]/10 border-[#60A5FA]/30 text-[#60A5FA]'
                          : isAward
                          ? 'bg-[#A78BFA]/10 border-[#A78BFA]/30 text-[#A78BFA]'
                          : 'bg-[#4ADE80]/10 border-[#4ADE80]/30 text-[#4ADE80]'
                      }`}
                    >
                      {isPatent ? (
                        <FileCode className="w-5 h-5" />
                      ) : isAward ? (
                        <Trophy className="w-5 h-5" />
                      ) : (
                        <Award className="w-5 h-5" />
                      )}
                    </div>

                    {item.badge && (
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-[#161D36] border border-white/[0.08] text-[#F3F4FF] font-code">
                        {item.badge}
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg font-bold text-[#F3F4FF]">
                    {item.title}
                  </h3>

                  <div className="text-xs font-semibold text-[#A78BFA] mt-1">
                    {item.issuer}
                  </div>

                  <p className="text-xs sm:text-sm text-[#A0A7C0] mt-3 leading-relaxed">
                    {item.details}
                  </p>
                </div>

                <div className="mt-5 pt-3 border-t border-white/[0.04] flex items-center justify-between text-[11px] text-[#A0A7C0]">
                  <span className="flex items-center gap-1 text-[#4ADE80]">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Verified Achievement</span>
                  </span>
                  <span className="font-code uppercase text-[#A0A7C0]/60">{item.type}</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
